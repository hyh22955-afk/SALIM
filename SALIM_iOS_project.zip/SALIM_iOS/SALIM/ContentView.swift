import SwiftUI

@main
struct SALIMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

struct ContentView: View {
    private let pink = Color(red: 1.0, green: 0.20, blue: 0.48)
    private let purple = Color(red: 0.58, green: 0.25, blue: 1.0)

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.055, green: 0.045, blue: 0.10), .black, Color(red: 0.10, green: 0.035, blue: 0.14)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            ).ignoresSafeArea()

            VStack(spacing: 22) {
                Spacer(minLength: 26)

                ZStack {
                    RoundedRectangle(cornerRadius: 34)
                        .fill(LinearGradient(colors: [purple.opacity(0.30), pink.opacity(0.18)], startPoint: .topLeading, endPoint: .bottomTrailing))
                        .frame(width: 150, height: 150)
                        .overlay(RoundedRectangle(cornerRadius: 34).stroke(.white.opacity(0.22), lineWidth: 1))
                    Image(systemName: "crown.fill")
                        .font(.system(size: 58, weight: .black))
                        .foregroundStyle(LinearGradient(colors: [.white, Color(red: 0.78, green: 0.63, blue: 1)], startPoint: .top, endPoint: .bottom))
                        .shadow(color: purple.opacity(0.8), radius: 18)
                }

                VStack(spacing: 6) {
                    Text("SALIM")
                        .font(.system(size: 38, weight: .black, design: .rounded))
                        .tracking(5)
                        .foregroundStyle(LinearGradient(colors: [.white, Color(red: 0.78, green: 0.65, blue: 1)], startPoint: .leading, endPoint: .trailing))
                    Text("YOUR SOCIAL SPACE")
                        .font(.system(size: 11, weight: .bold, design: .rounded))
                        .tracking(3)
                        .foregroundStyle(.white.opacity(0.55))
                }

                VStack(spacing: 12) {
                    Link(destination: URL(string: "https://www.instagram.com/")!) {
                        Label("فتح Instagram", systemImage: "camera.fill")
                            .font(.system(size: 16, weight: .bold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 17)
                            .background(LinearGradient(colors: [pink, purple], startPoint: .leading, endPoint: .trailing))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                    Link(destination: URL(string: "https://help.instagram.com/")!) {
                        Label("مركز مساعدة Instagram", systemImage: "questionmark.circle")
                            .font(.system(size: 15, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(.white.opacity(0.07))
                            .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(0.12), lineWidth: 1))
                            .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                }
                .padding(.horizontal, 26)

                Spacer()

                Text("SALIM • تصميم مستقل غير تابع لشركة Instagram")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundStyle(.white.opacity(0.42))
                    .padding(.bottom, 18)
            }
            .padding()
        }
    }
}
