SALIM iOS — مشروع Xcode
========================
هذا مشروع تطبيق iOS أصلي بواجهة SALIM وزر يفتح Instagram الرسمي.
ليس نسخة معدلة من Instagram ولا يتضمن تسجيل دخول أو وصولاً إلى حسابات الغير.

البناء على Mac:
1) افتح SALIM.xcodeproj في Xcode.
2) اختر Target: SALIM ثم Signing & Capabilities.
3) اختر Team الخاص بك وغيّر Bundle Identifier إذا لزم.
4) اختر جهاز iPhone أو Any iOS Device ثم Product > Archive.
5) من Organizer اختر Distribute App لإخراج IPA موقّع وفق حساب Apple الخاص بك.

أمر بناء تجريبي على Mac:
xcodebuild -project SALIM.xcodeproj -scheme SALIM -configuration Release -sdk iphoneos -archivePath build/SALIM.xcarchive archive

يتطلب إخراج IPA وتثبيته توقيع Apple صالحاً. لا يمكن إنشاء IPA موقّع من بيئة Linux الحالية.
